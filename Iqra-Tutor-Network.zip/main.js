/* ══════════════════════════════════════════════════════════════
   IQRA TUTOR NETWORK – main.js
   ══════════════════════════════════════════════════════════════ */

'use strict';

/* ─── CONFIG ──────────────────────────────────────────────────
   Update these values to configure the page for production.
   ─────────────────────────────────────────────────────────── */
const CONFIG = {
  TUTOR_REGISTRATION_URL:
    'https://docs.google.com/forms/d/e/1FAIpQLSd3MeF2MW2JxgwvosRw3t-cynx04A4gH8ZKEYZuBL3fkk2Ocg/viewform?usp=header',
  WHATSAPP_NUMBER: '8801572929029',
  FOOTER_YEAR: new Date().getFullYear(),
  // Set these to real URLs when pages are ready
  ABOUT_US_URL:          '#',
  PRIVACY_POLICY_URL:    '#',
  TERMS_URL:             '#',
  COMMISSION_POLICY_URL: '#commission',
};

/* ─── Inject Config into DOM ─────────────────────────────────── */
function applyConfig() {
  // Tutor registration CTA links
  const regLinks = document.querySelectorAll('a[href="TUTOR_REGISTRATION_URL"]');
  regLinks.forEach(link => {
    link.href = CONFIG.TUTOR_REGISTRATION_URL;
  });

  // WhatsApp links
  const waLinks = document.querySelectorAll('a[href^="https://wa.me/"]');
  waLinks.forEach(link => {
    link.href = `https://wa.me/${CONFIG.WHATSAPP_NUMBER}`;
  });

  // Legal links
  document.querySelectorAll('a[href="ABOUT_US_URL"]').forEach(l => { l.href = CONFIG.ABOUT_US_URL; });
  document.querySelectorAll('a[href="PRIVACY_POLICY_URL"]').forEach(l => { l.href = CONFIG.PRIVACY_POLICY_URL; });
  document.querySelectorAll('a[href="TERMS_URL"]').forEach(l => { l.href = CONFIG.TERMS_URL; });
  document.querySelectorAll('a[href="COMMISSION_POLICY_URL"]').forEach(l => { l.href = CONFIG.COMMISSION_POLICY_URL; });

  // Footer year
  const yearEl = document.getElementById('footer-year');
  if (yearEl) yearEl.textContent = CONFIG.FOOTER_YEAR;
}

/* ─── Navbar: scroll shadow + active class ───────────────────── */
function initNavbar() {
  const navbar = document.getElementById('navbar');
  if (!navbar) return;

  const onScroll = () => {
    navbar.classList.toggle('scrolled', window.scrollY > 10);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

/* ─── Hamburger Menu ─────────────────────────────────────────── */
function initMobileMenu() {
  const hamburger = document.getElementById('hamburger');
  const navLinks  = document.getElementById('nav-links');
  if (!hamburger || !navLinks) return;

  hamburger.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    hamburger.classList.toggle('open', isOpen);
    hamburger.setAttribute('aria-expanded', String(isOpen));
  });

  // Close when a link is clicked
  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('open');
      hamburger.classList.remove('open');
      hamburger.setAttribute('aria-expanded', 'false');
    });
  });

  // Close on outside click
  document.addEventListener('click', e => {
    if (!navbar.contains(e.target)) {
      navLinks.classList.remove('open');
      hamburger.classList.remove('open');
      hamburger.setAttribute('aria-expanded', 'false');
    }
  });
}

/* ─── FAQ Accordion ──────────────────────────────────────────── */
function initFAQ() {
  const faqList = document.getElementById('faq-list');
  if (!faqList) return;

  faqList.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const item   = btn.closest('.faq-item');
      const answer = document.getElementById(btn.getAttribute('aria-controls'));
      const isOpen = btn.getAttribute('aria-expanded') === 'true';

      // Close all others
      faqList.querySelectorAll('.faq-item').forEach(i => {
        i.classList.remove('open');
        i.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
        const a = i.querySelector('.faq-answer');
        if (a) a.classList.remove('open');
      });

      // Toggle clicked
      if (!isOpen) {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
        if (answer) answer.classList.add('open');
      }
    });
  });
}

/* ─── Smooth Scroll for anchor links ────────────────────────── */
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', e => {
      const id = anchor.getAttribute('href').slice(1);
      if (!id) return;
      const target = document.getElementById(id);
      if (!target) return;
      e.preventDefault();
      const navH = document.getElementById('navbar')?.offsetHeight || 70;
      const top  = target.getBoundingClientRect().top + window.scrollY - navH - 8;
      window.scrollTo({ top, behavior: 'smooth' });
    });
  });
}

/* ─── Scroll-reveal IntersectionObserver ────────────────────── */
function initScrollReveal() {
  const options = { threshold: 0.12, rootMargin: '0px 0px -40px 0px' };
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, options);

  document.querySelectorAll('.reveal, .stagger-children').forEach(el => {
    observer.observe(el);
  });
}

/* ─── Add reveal classes to sections programmatically ──────── */
function decorateReveal() {
  // Section headings reveal
  document.querySelectorAll('.section-label, .section-title, .section-subtitle').forEach(el => {
    el.classList.add('reveal');
  });
  // Benefit grid stagger
  const benefitsGrid = document.querySelector('.benefits-grid');
  if (benefitsGrid) benefitsGrid.classList.add('stagger-children');

  // Steps grid stagger
  const stepsGrid = document.querySelector('.steps-grid');
  if (stepsGrid) stepsGrid.classList.add('stagger-children');

  // Who grid
  const whoGrid = document.querySelector('.who-grid');
  if (whoGrid) whoGrid.classList.add('stagger-children');

  // Subject grid
  const subjectsGrid = document.querySelector('.subjects-grid');
  if (subjectsGrid) subjectsGrid.classList.add('stagger-children');

  // Trust grid
  const trustGrid = document.querySelector('.trust-grid');
  if (trustGrid) trustGrid.classList.add('stagger-children');

  // FAQ items
  document.querySelectorAll('.faq-item').forEach(el => el.classList.add('reveal'));

  // Final CTA card
  const finalCard = document.querySelector('.final-cta-card');
  if (finalCard) finalCard.classList.add('reveal');

  // Hero visual
  const heroVisual = document.querySelector('.hero-visual');
  if (heroVisual) heroVisual.classList.add('reveal');

  // Commission card
  const commissionCard = document.querySelector('.commission-card');
  if (commissionCard) commissionCard.classList.add('reveal');
}

/* ─── Active nav link on scroll ─────────────────────────────── */
function initActiveNav() {
  const sections = ['benefits', 'how-it-works', 'faq'];
  const navLinks = document.querySelectorAll('.nav-link');

  const onScroll = () => {
    const scrollY = window.scrollY + 100;
    sections.forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      if (scrollY >= el.offsetTop && scrollY < el.offsetTop + el.offsetHeight) {
        navLinks.forEach(link => link.classList.remove('nav-active'));
        const match = document.querySelector(`.nav-link[href="#${id}"]`);
        if (match) match.classList.add('nav-active');
      }
    });
  };
  window.addEventListener('scroll', onScroll, { passive: true });
}

/* ─── Init ───────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  applyConfig();
  initNavbar();
  initMobileMenu();
  initFAQ();
  initSmoothScroll();
  decorateReveal();
  // Slight delay so CSS transitions are in place before reveal
  requestAnimationFrame(() => {
    setTimeout(initScrollReveal, 100);
  });
  initActiveNav();
});
